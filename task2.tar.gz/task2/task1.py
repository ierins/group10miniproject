import numpy as np
import cv2

img = cv2.imread("2.png")

samples = np.loadtxt('char_samples.data',np.float32)
responses = np.loadtxt('char_responses.data',np.float32)
responses = responses.reshape((responses.size,1))


model = cv2.ml.KNearest_create()
model.train(samples, cv2.ml.ROW_SAMPLE, responses)

img = np.float32(img)
retval, results, neigh_resp, dists = model.findNearest(img, k = 1)
print(results)




